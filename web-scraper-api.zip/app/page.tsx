"use client"

import  from "../src/server"

export default function SyntheticV0PageForDeployment() {
  return < />
}