import express from "express"
import cors from "cors"
import dotenv from "dotenv"
import { scrapeAnimeList, scrapeAnimeDetails, scrapeRecommendations } from "./scrapers/animeScrapers.js"

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json())

// Health check endpoint
app.get("/health", (req, res) => {
  res.json({ status: "OK", timestamp: new Date().toISOString() })
})

// API Routes
app.get("/api/anime", async (req, res) => {
  try {
    const { page = 1, search } = req.query
    const data = await scrapeAnimeList(page, search)
    res.json({ success: true, data })
  } catch (error) {
    res.status(500).json({ success: false, error: error.message })
  }
})

app.get("/api/anime/:id", async (req, res) => {
  try {
    const data = await scrapeAnimeDetails(req.params.id)
    res.json({ success: true, data })
  } catch (error) {
    res.status(500).json({ success: false, error: error.message })
  }
})

app.get("/api/recommendations", async (req, res) => {
  try {
    const data = await scrapeRecommendations()
    res.json({ success: true, data })
  } catch (error) {
    res.status(500).json({ success: false, error: error.message })
  }
})

// Root endpoint with API documentation
app.get("/", (req, res) => {
  res.json({
    message: "WeebCentral Scraper API",
    version: "1.0.0",
    endpoints: {
      health: "GET /health",
      animeList: "GET /api/anime?page=1&search=query",
      animeDetails: "GET /api/anime/:id",
      recommendations: "GET /api/recommendations",
    },
    docs: "Visit endpoints above for data",
  })
})

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
  console.log(`Environment: ${process.env.NODE_ENV || "development"}`)
})
