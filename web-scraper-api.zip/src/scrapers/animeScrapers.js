import axios from "axios"
import * as cheerio from "cheerio"

const BASE_URL = "https://weebcentral.com"
const TIMEOUT = 10000

const axiosConfig = {
  timeout: TIMEOUT,
  headers: {
    "User-Agent":
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
  },
}

export async function scrapeAnimeList(page = 1, search = null) {
  try {
    const url = search
      ? `${BASE_URL}/search?q=${encodeURIComponent(search)}&page=${page}`
      : `${BASE_URL}/anime?page=${page}`

    const response = await axios.get(url, axiosConfig)
    const $ = cheerio.load(response.data)

    const animeList = []

    // Adjust selectors based on weebcentral.com structure
    $("[data-anime-item], .anime-card, .anime-item").each((index, element) => {
      const $item = $(element)
      const anime = {
        id: $item.attr("data-id") || $item.find("a").attr("href")?.split("/").pop(),
        title: $item.find(".title, h2, .anime-title").text().trim(),
        image: $item.find("img").attr("src"),
        rating: $item.find(".rating, [data-rating]").text().trim(),
        description: $item.find(".description, .summary, p").first().text().trim().substring(0, 150),
        url: $item.find("a").attr("href"),
      }

      if (anime.title) animeList.push(anime)
    })

    return {
      page: Number.parseInt(page),
      results: animeList,
      count: animeList.length,
    }
  } catch (error) {
    throw new Error(`Failed to scrape anime list: ${error.message}`)
  }
}

export async function scrapeAnimeDetails(animeId) {
  try {
    const url = `${BASE_URL}/anime/${animeId}`
    const response = await axios.get(url, axiosConfig)
    const $ = cheerio.load(response.data)

    const details = {
      id: animeId,
      title: $("h1, .title, [data-title]").first().text().trim(),
      image: $("img.poster, [data-poster]").attr("src"),
      rating: $("[data-rating], .rating").text().trim(),
      status: $("[data-status], .status").text().trim(),
      year: $("[data-year], .year").text().trim(),
      genres: [],
      description: $("[data-synopsis], .description, .synopsis").text().trim(),
      episodes: $("[data-episodes], .episodes").text().trim(),
      studios: $("[data-studio], .studio").text().trim(),
      score: $("[data-score], .score").text().trim(),
    }

    // Extract genres
    $("[data-genre], .genre, .genres a").each((index, element) => {
      const genre = $(element).text().trim()
      if (genre) details.genres.push(genre)
    })

    return details
  } catch (error) {
    throw new Error(`Failed to scrape anime details: ${error.message}`)
  }
}

export async function scrapeRecommendations() {
  try {
    const url = `${BASE_URL}/recommendations`
    const response = await axios.get(url, axiosConfig)
    const $ = cheerio.load(response.data)

    const recommendations = []

    // Adjust selector for recommendations section
    $("[data-recommendation], .recommendation-item, .recommended").each((index, element) => {
      const $item = $(element)
      const rec = {
        id: $item.attr("data-id"),
        title: $item.find(".title, h3").text().trim(),
        reason: $item.find(".reason, .note").text().trim(),
        image: $item.find("img").attr("src"),
        link: $item.find("a").attr("href"),
      }

      if (rec.title) recommendations.push(rec)
    })

    return {
      recommendations,
      count: recommendations.length,
    }
  } catch (error) {
    throw new Error(`Failed to scrape recommendations: ${error.message}`)
  }
}
